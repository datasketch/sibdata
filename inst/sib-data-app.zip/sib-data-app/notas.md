

ocultar salobres
boyacá, santander, tolima y todos


Nombres filtros:
tipo registro -> "Tipo"
modo?

tematica
amenazadas
 - Global
 - Nacional
cites
endemicas
migratorias
exoticas
invasoras
exoticas_riesgo_invasion

Ver cuáles parejas de variales tienen sentido:
Ej:
- Categoría amenza vs Global o nacional



Separar vista de tabla de visualizaciones





Temáticas:
Todas: solo para la tabla

amenazadas ->
o global o nacional
-> subcategorias


Amenzadas:
alcance geográfico

cites: apendice
I II y III
I-II solo para colombia


Qué hacer con la información faltante:
Si es 0 se muestra, si es NA no se muestra



Alerta: Cuando vemos cobertura:
"Texto aclaratorio"










V2:
Marinas y continentales












